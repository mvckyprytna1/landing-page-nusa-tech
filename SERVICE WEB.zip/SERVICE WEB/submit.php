<?php
// submit.php
session_start();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Method Not Allowed']);
    exit;
}

// Validasi CSRF Token
if (!isset($_POST['csrf_token']) || !isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    echo json_encode(['status' => 'error', 'message' => 'Token keamanan tidak valid. Silakan refresh halaman.']);
    exit;
}

// Sanitasi & Validasi Input
$name = trim(filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING) ?? '');
$phone = trim(filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_STRING) ?? '');
$device = trim(filter_input(INPUT_POST, 'device', FILTER_SANITIZE_STRING) ?? '');
$service = trim(filter_input(INPUT_POST, 'service', FILTER_SANITIZE_STRING) ?? '');
$issue = trim(filter_input(INPUT_POST, 'issue', FILTER_SANITIZE_STRING) ?? '');

// Cek required
if (empty($name) || empty($phone) || empty($device) || empty($service) || empty($issue)) {
    echo json_encode(['status' => 'error', 'message' => 'Semua field wajib diisi dengan benar.']);
    exit;
}

// Limit panjang karakter (keamanan tambahan)
if (strlen($name) > 50 || strlen($phone) > 20 || strlen($issue) > 500) {
    echo json_encode(['status' => 'error', 'message' => 'Terdapat input yang melebihi batas karakter.']);
    exit;
}

// Persiapan simpan ke CSV
$storageDir = __DIR__ . '/storage';
$storageFile = $storageDir . '/leads.csv';

// Bikin folder kalau nggak ada
if (!is_dir($storageDir)) {
    mkdir($storageDir, 0755, true);
}

$date = date('Y-m-d H:i:s');
$csvData = [$date, $name, $phone, $device, $service, $issue];
$file_exists = file_exists($storageFile);

// Tulis ke CSV
$fp = @fopen($storageFile, 'a');
if ($fp) {
    if (!$file_exists) {
        fputcsv($fp, ['Tanggal', 'Nama', 'WhatsApp', 'Perangkat', 'Layanan', 'Keluhan']); // Header
    }
    fputcsv($fp, $csvData);
    fclose($fp);
} else {
    // Logging internal jika error tulis, jangan lempar path ke frontend
    error_log("Failed writing to leads CSV file.");
}

// Siapkan pesan WA
$waText = "Halo *NusaTech Care*,\n\n";
$waText .= "Saya mau konsultasi perbaikan perangkat:\n\n";
$waText .= "👤 *Nama:* $name\n";
$waText .= "📱 *WA:* $phone\n";
$waText .= "💻 *Perangkat:* $device\n";
$waText .= "🛠 *Layanan:* $service\n";
$waText .= "📝 *Keluhan:* $issue\n\n";
$waText .= "Mohon direspon estimasi dan langkah selanjutnya. Terima kasih.";

echo json_encode([
    'status' => 'success',
    'message' => 'Berhasil! Mengalihkan ke WhatsApp...',
    'wa_url' => 'https://wa.me/' . '6281252580812' . '?text=' . rawurlencode($waText) // Nomor diambil via JS nanti aslinya, atau hardcode sini sbg fallback
]);
exit;
?>