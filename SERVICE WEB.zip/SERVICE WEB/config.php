<?php
// config.php
$config = [
    'brand_name' => 'NusaTech Care',
    'tagline' => 'Jasa Service Laptop, PC, dan Android',
    'description' => 'Bantu cek, diagnosa, perbaikan software, instal ulang, backup data, upgrade, sampai optimasi perangkat dengan proses yang jelas dan estimasi transparan.',
    'whatsapp' => '6281252580812',
    'email' => 'halo@nusatechcareservice.com',
    'location' => 'Jambi City, Jambi, Indonesia',
    'business_hours' => 'Senin - Sabtu: 09:00 - 20:00 WIB',
];

$hero_stats = [
    ['value' => '30+', 'label' => 'Jenis Kendala'],
    ['value' => '1-3 Jam', 'label' => 'Diagnosa Awal'],
    ['value' => '100%', 'label' => 'Transparan']
];

$services = [
    ['icon' => 'laptop', 'category' => 'Hardware & System', 'title' => 'Service Laptop & PC', 'desc' => 'Perbaikan motherboard, mati total, layar blank, keyboard, hingga baterai.', 'benefits' => ['Diagnosa Akurat', 'Part Original', 'Bergaransi']],
    ['icon' => 'smartphone', 'category' => 'Mobile Devices', 'title' => 'Service Android', 'desc' => 'Ganti LCD, konektor charger, bootloop, hingga perbaikan IC.', 'benefits' => ['Pengerjaan Rapi', 'Aman dari Mati Total', 'Cek Transparan']],
    ['icon' => 'disc', 'category' => 'Software', 'title' => 'Install Ulang OS', 'desc' => 'Windows/Linux, full driver, dan aplikasi standar lengkap.', 'benefits' => ['Tanpa Bloatware', 'Sistem Lebih Enteng', 'Bonus Aplikasi Dasar']],
    ['icon' => 'database', 'category' => 'Data Recovery', 'title' => 'Backup & Recovery Data', 'desc' => 'Penyelamatan data dari hardisk rusak, terformat, atau laptop mati.', 'benefits' => ['Privasi Aman 100%', 'Tingkat Sukses Tinggi', 'Storage Tersedia']],
    ['icon' => 'cpu', 'category' => 'Hardware', 'title' => 'Upgrade SSD/RAM', 'desc' => 'Bikin perangkat lemot jadi ngebut hitungan detik tanpa harus beli baru.', 'benefits' => ['Performa Naik Signifikan', 'Bebas Antri', 'Konsultasi Gratis']],
    ['icon' => 'wind', 'category' => 'Maintenance', 'title' => 'Cleaning & Thermal', 'desc' => 'Pembersihan debu total dan repaste thermal paste atasi overheat.', 'benefits' => ['Suhu Jadi Adem', 'Awet Tahan Lama', 'Thermal Paste Premium']],
];

$steps = [
    ['title' => 'Ceritakan Kendala', 'desc' => 'Jelaskan masalah perangkat lu via WhatsApp dengan detail.'],
    ['title' => 'Cek & Diagnosa', 'desc' => 'Kita cek menyeluruh untuk menemukan sumber masalah pasti.'],
    ['title' => 'Estimasi Biaya', 'desc' => 'Lu bakal dapat rincian biaya transparan sebelum dibongkar/dieksekusi.'],
    ['title' => 'Pengerjaan', 'desc' => 'Proses perbaikan dilakukan dengan rapi dan hati-hati sesuai SOP.'],
    ['title' => 'Testing Akhir', 'desc' => 'Perangkat diuji coba untuk memastikan semuanya normal.'],
    ['title' => 'Serah Terima', 'desc' => 'Perangkat siap diambil lengkap dengan saran perawatan.']
];

$advantages = [
    ['title' => 'Diagnosa Tidak Asal Tebak', 'desc' => 'Pengecekan berbasis data dan tes terukur, bukan sekadar nebak penyakit.'],
    ['title' => 'Estimasi Transparan', 'desc' => 'Biaya diinfokan di awal. Nggak ada biaya gaib yang tiba-tiba membengkak.'],
    ['title' => 'Data Diprioritaskan', 'desc' => 'Keamanan dan privasi data lu adalah hal utama sebelum eksekusi sistem.'],
    ['title' => 'Update Berkala', 'desc' => 'Lu nggak perlu was-was, kita kasih update status pengerjaan perangkat lu.'],
    ['title' => 'Konsultasi Santai', 'desc' => 'Masih bingung? Tanya-tanya dulu aja gratis. Kita kasih solusi terbaik.'],
    ['title' => 'Pengerjaan Rapi', 'desc' => 'Baut nggak kurang, kabel nggak berantakan. Kerapian adalah standar kita.']
];

$packages = [
    ['name' => 'Cek Awal', 'price' => 'Rp30K', 'desc' => 'Harga cek awal dibuat mengikuti kalkulator internal untuk diagnosa ringan sebelum tindakan besar.', 'features' => ['Diagnosa awal perangkat', 'Estimasi biaya dari kalkulator', 'Saran tindakan sebelum eksekusi'], 'popular' => false],
    ['name' => 'Service Software', 'price' => 'Rp150K - Rp250K', 'desc' => 'Range umum untuk perbaikan software/driver, optimasi, repair OS ringan, dan testing fungsi dasar.', 'features' => ['Perbaikan driver/software', 'Repair OS sesuai scope', 'Testing fungsi dasar', 'Harga final setelah diagnosa'], 'popular' => true],
    ['name' => 'Service Lengkap', 'price' => 'Sesuai Diagnosa', 'desc' => 'Untuk hardware, sparepart, recovery data, atau kasus berat. Harga mengikuti hasil cek dan kalkulator final.', 'features' => ['Sparepart dihitung terpisah', 'DP jika perlu beli part', 'Testing & QC akhir', 'Nota pengerjaan profesional'], 'popular' => false]
];

$testimonials = [
    ['text' => 'Laptop awalnya lemot banget, setelah dicek ternyata storage bermasalah. Dijelasin dulu sebelum dikerjakan, jadi lebih tenang dan harganya jelas di awal.', 'name' => 'Budi S.', 'device' => 'Laptop ASUS'],
    ['text' => 'HP bootloop dikira harus ganti mesin mahal, ternyata bisa diflashing rapi. Data juga aman diselamatin. Mantap pelayanannya.', 'name' => 'Dinda R.', 'device' => 'Android Xiaomi'],
    ['text' => 'Pengerjaannya rapi, baut lengkap nggak ada yang ilang. Upgrade SSD sekalian cleaning langsung berasa beli PC baru. Recommended!', 'name' => 'Andi T.', 'device' => 'PC Rakitan']
];

$faqs = [
    ['q' => 'Apakah bisa konsultasi dulu?', 'a' => 'Tentu. Lu bisa cerita keluhannya di WhatsApp. Gua bantu cek estimasi awalnya secara gratis.'],
    ['q' => 'Berapa lama pengerjaan?', 'a' => 'Install ulang & software 1-3 jam. Upgrade part ringan 1 hari. Service hardware berat (mati total) 3-7 hari kerja tergantung ketersediaan part.'],
    ['q' => 'Apakah data aman?', 'a' => 'Keamanan data prioritas utama. Kalau misal harus format, pasti gua konfirmasi dulu dan usahakan backup (ada biaya tambahan untuk backup besar).'],
    ['q' => 'Apakah bisa service panggilan?', 'a' => 'Saat ini lebih fokus pengerjaan di tempat agar tools diagnosa lengkap dan maksimal. Tapi lu bisa drop unit lewat kurir instan.'],
    ['q' => 'Apakah ada garansi pengerjaan?', 'a' => 'Pasti. Garansi software 1 minggu, garansi perbaikan hardware 1 bulan (syarat & ketentuan berlaku), garansi part baru sesuai distributor resmi.'],
    ['q' => 'Apakah bisa install aplikasi juga?', 'a' => 'Bisa. Untuk install ulang otomatis dapat aplikasi standar (Browser, Office, PDF). Request aplikasi berat (Design/Video) harap infokan di awal.']
];

// Helper Icon Function (SVG Inline biar cepat)
function getIcon($name) {
    $icons = [
        'laptop' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect><line x1="2" y1="20" x2="22" y2="20"></line></svg>',
        'smartphone' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"></rect><line x1="12" y1="18" x2="12.01" y2="18"></line></svg>',
        'disc' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><circle cx="12" cy="12" r="3"></circle></svg>',
        'database' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><ellipse cx="12" cy="5" rx="9" ry="3"></ellipse><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"></path><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"></path></svg>',
        'cpu' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect><rect x="9" y="9" width="6" height="6"></rect><line x1="9" y1="1" x2="9" y2="4"></line><line x1="15" y1="1" x2="15" y2="4"></line><line x1="9" y1="20" x2="9" y2="23"></line><line x1="15" y1="20" x2="15" y2="23"></line><line x1="20" y1="9" x2="23" y2="9"></line><line x1="20" y1="14" x2="23" y2="14"></line><line x1="1" y1="9" x2="4" y2="9"></line><line x1="1" y1="14" x2="4" y2="14"></line></svg>',
        'wind' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9.59 4.59A2 2 0 1 1 11 8H2m10.59 11.41A2 2 0 1 0 14 16H2m15.73-8.27A2.5 2.5 0 1 1 19.5 12H2"></path></svg>'
    ];
    return $icons[$name] ?? '';
}
?>