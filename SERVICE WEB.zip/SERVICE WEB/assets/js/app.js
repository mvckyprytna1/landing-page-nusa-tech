// assets/js/app.js

document.addEventListener('DOMContentLoaded', () => {

    // 1. Mobile Menu Toggle
    const hamburger = document.getElementById('hamburger');
    const navLinks = document.getElementById('nav-links');
    const navItems = document.querySelectorAll('.nav-item');

    if (hamburger && navLinks) {
        hamburger.addEventListener('click', () => {
            hamburger.classList.toggle('active');
            navLinks.classList.toggle('active');
        });

        navItems.forEach(item => {
            item.addEventListener('click', () => {
                hamburger.classList.remove('active');
                navLinks.classList.remove('active');
            });
        });
    }

    // 2. Sticky Navbar
    const navbar = document.getElementById('navbar');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 20) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });

    // 3. Scroll Reveal Animation (Intersection Observer)
    const revealElements = document.querySelectorAll('.reveal-up');
    const revealOptions = {
        threshold: 0.1,
        rootMargin: "0px 0px -50px 0px"
    };

    const revealOnScroll = new IntersectionObserver(function(entries, observer) {
        entries.forEach(entry => {
            if (!entry.isIntersecting) return;
            entry.target.classList.add('active');
            observer.unobserve(entry.target); // Hanya animasi sekali
        });
    }, revealOptions);

    revealElements.forEach(el => revealOnScroll.observe(el));

    // 4. FAQ Accordion
    const faqItems = document.querySelectorAll('.faq-item');
    faqItems.forEach(item => {
        const btn = item.querySelector('.faq-question');
        btn.addEventListener('click', () => {
            const isActive = item.classList.contains('active');
            
            // Close all others
            faqItems.forEach(other => {
                other.classList.remove('active');
                other.querySelector('.faq-answer').style.maxHeight = null;
            });

            // Open clicked if it wasn't active
            if (!isActive) {
                item.classList.add('active');
                const answer = item.querySelector('.faq-answer');
                answer.style.maxHeight = answer.scrollHeight + "px";
            }
        });
    });

    // 5. Form Submit via AJAX
    const form = document.getElementById('consultForm');
    const btnSubmit = document.getElementById('btnSubmit');
    const formAlert = document.getElementById('form-alert');

    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();

            // Reset State
            btnSubmit.innerHTML = 'Memproses... <span style="display:inline-block; animation: spin 1s linear infinite;">⏳</span>';
            btnSubmit.disabled = true;
            formAlert.classList.add('d-none');
            formAlert.className = 'alert'; // Reset classes

            const formData = new FormData(form);

            try {
                const response = await fetch('submit.php', {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'Accept': 'application/json'
                    }
                });

                const data = await response.json();

                if (response.ok && data.status === 'success') {
                    // Success UI
                    formAlert.textContent = data.message;
                    formAlert.classList.add('success');
                    formAlert.classList.remove('d-none');
                    form.reset();

                    // Redirect to WA via dynamic JS data or backend generated URL
                    setTimeout(() => {
                        window.open(data.wa_url, '_blank');
                        btnSubmit.innerHTML = 'Kirim & Chat WhatsApp';
                        btnSubmit.disabled = false;
                    }, 1500);

                } else {
                    throw new Error(data.message || 'Terjadi kesalahan pada server.');
                }

            } catch (error) {
                // Error UI
                formAlert.textContent = error.message;
                formAlert.classList.add('error');
                formAlert.classList.remove('d-none');
                btnSubmit.innerHTML = 'Kirim & Chat WhatsApp';
                btnSubmit.disabled = false;
            }
        });
    }
});