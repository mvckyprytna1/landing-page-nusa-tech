<?php
session_start();
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
require_once 'config.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($config['brand_name']) ?> | <?= htmlspecialchars($config['tagline']) ?></title>
    <meta name="description" content="<?= htmlspecialchars($config['description']) ?>">
    <meta property="og:title" content="<?= htmlspecialchars($config['brand_name']) ?> | Professional Tech Service">
    <meta property="og:description" content="<?= htmlspecialchars($config['description']) ?>">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

    <nav class="navbar" id="navbar">
        <div class="container nav-container">
            <a href="#" class="logo">
                <span class="logo-accent"></span>
                <?= htmlspecialchars($config['brand_name']) ?>
            </a>
            <div class="nav-links" id="nav-links">
                <a href="#hero" class="nav-item">Home</a>
                <a href="#services" class="nav-item">Layanan</a>
                <a href="#workflow" class="nav-item">Alur</a>
                <a href="#pricing" class="nav-item">Paket</a>
                <a href="#advantages" class="nav-item">Keunggulan</a>
                <a href="#faq" class="nav-item">FAQ</a>
            </div>
            <div class="nav-actions">
                <a href="#contact" class="btn btn-primary d-none-mobile">Chat WhatsApp</a>
                <button class="hamburger" id="hamburger" aria-label="Toggle Menu">
                    <span></span><span></span><span></span>
                </button>
            </div>
        </div>
    </nav>

    <header class="hero" id="hero">
        <div class="container hero-grid">
            <div class="hero-content reveal-up">
                <div class="badge-group">
                    <span class="badge badge-outline">Estimasi Jelas</span>
                    <span class="badge badge-outline">Respons Cepat</span>
                    <span class="badge badge-outline">Data Diprioritaskan</span>
                </div>
                <h1>Service Perangkat <br>Lebih Jelas, Rapi, dan <br><span class="text-gradient">Nggak Bikin Nebak-Nebak.</span></h1>
                <p class="hero-desc"><?= htmlspecialchars($config['description']) ?></p>
                <div class="hero-cta">
                    <a href="#contact" class="btn btn-primary btn-lg">Konsultasi Sekarang</a>
                    <a href="#services" class="btn btn-secondary btn-lg">Lihat Layanan</a>
                </div>
                <div class="hero-stats">
                    <?php foreach($hero_stats as $stat): ?>
                        <div class="stat-item">
                            <span class="stat-value"><?= htmlspecialchars($stat['value']) ?></span>
                            <span class="stat-label"><?= htmlspecialchars($stat['label']) ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="hero-visual reveal-up delay-2">
                <div class="diagnostic-card">
                    <div class="diag-header">
                        <div class="diag-dots"><span></span><span></span><span></span></div>
                        <div class="diag-title">System Diagnostics</div>
                    </div>
                    <div class="diag-body">
                        <div class="diag-status scanning">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
                            <span>Scanning System Health...</span>
                        </div>
                        <div class="progress-group">
                            <div class="progress-label"><span>Storage State</span><span>Warning</span></div>
                            <div class="progress-bar"><div class="fill warning" style="width: 85%"></div></div>
                        </div>
                        <div class="progress-group">
                            <div class="progress-label"><span>Thermal Level</span><span>Critical</span></div>
                            <div class="progress-bar"><div class="fill danger" style="width: 92%"></div></div>
                        </div>
                        <div class="progress-group">
                            <div class="progress-label"><span>Memory Integrity</span><span>Optimal</span></div>
                            <div class="progress-bar"><div class="fill success" style="width: 45%"></div></div>
                        </div>
                        <div class="diag-action">
                            <div class="action-btn">Repair Recommended</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <section class="section bg-light" id="services">
        <div class="container">
            <div class="section-header reveal-up">
                <h2 class="section-title">Layanan Profesional</h2>
                <p class="section-subtitle">Spesialisasi mengembalikan performa perangkat lu seperti baru.</p>
            </div>
            <div class="grid cards-grid">
                <?php foreach($services as $srv): ?>
                <div class="card service-card reveal-up">
                    <div class="card-icon"><?= getIcon($srv['icon']) ?></div>
                    <span class="card-category"><?= htmlspecialchars($srv['category']) ?></span>
                    <h3 class="card-title"><?= htmlspecialchars($srv['title']) ?></h3>
                    <p class="card-desc"><?= htmlspecialchars($srv['desc']) ?></p>
                    <ul class="card-list">
                        <?php foreach($srv['benefits'] as $bnf): ?>
                            <li><?= htmlspecialchars($bnf) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <section class="section" id="workflow">
        <div class="container">
            <div class="section-header reveal-up">
                <h2 class="section-title">Alur Kerja Transparan</h2>
                <p class="section-subtitle">Nggak ada yang disembunyikan. Langkahnya jelas dari masuk sampai selesai.</p>
            </div>
            <div class="timeline-grid">
                <?php foreach($steps as $index => $step): ?>
                <div class="timeline-item reveal-up delay-<?= ($index % 3) + 1 ?>">
                    <div class="timeline-num">0<?= $index + 1 ?></div>
                    <h4 class="timeline-title"><?= htmlspecialchars($step['title']) ?></h4>
                    <p class="timeline-desc"><?= htmlspecialchars($step['desc']) ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <section class="section bg-light" id="before-after">
        <div class="container">
            <div class="section-header reveal-up">
                <h2 class="section-title">Perbedaan Nyata</h2>
            </div>
            <div class="ba-grid reveal-up">
                <div class="ba-card before">
                    <div class="ba-header">Sebelum Service</div>
                    <ul class="ba-list">
                        <li>Laptop lemot & gampang panas</li>
                        <li>Sering blue screen / aplikasi error</li>
                        <li>Takut biaya tiba-tiba membengkak</li>
                        <li>Tidak paham detail kerusakan</li>
                        <li>Was-was data hilang</li>
                    </ul>
                </div>
                <div class="ba-card after">
                    <div class="ba-header">Sesudah Service</div>
                    <ul class="ba-list">
                        <li>Perangkat ngebut siap diajak tempur</li>
                        <li>Sistem stabil dan bersih dari virus</li>
                        <li>Estimasi biaya jelas sebelum eksekusi</li>
                        <li>Paham masalah berkat edukasi teknisi</li>
                        <li>Data dan privasi dijaga penuh</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <section class="section" id="advantages">
        <div class="container">
            <div class="section-header reveal-up">
                <h2 class="section-title">Kenapa Memilih Kami?</h2>
                <p class="section-subtitle">Fokus kami bukan cuma perbaikan, tapi juga ketenangan pikiran lu.</p>
            </div>
            <div class="grid adv-grid">
                <?php foreach($advantages as $adv): ?>
                <div class="adv-item reveal-up">
                    <div class="adv-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"></polyline></svg></div>
                    <div>
                        <h4 class="adv-title"><?= htmlspecialchars($adv['title']) ?></h4>
                        <p class="adv-desc"><?= htmlspecialchars($adv['desc']) ?></p>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <section class="section bg-navy" id="pricing">
        <div class="container">
            <div class="section-header text-white reveal-up">
                <h2 class="section-title text-white">Estimasi Paket Harga</h2>
                <p class="section-subtitle">Range paket disesuaikan dengan kalkulator internal. Harga final tetap mengikuti hasil diagnosa dan persetujuan client.</p>
            </div>
            <div class="grid pricing-grid">
                <?php foreach($packages as $pkg): ?>
                <div class="price-card <?= $pkg['popular'] ? 'popular' : '' ?> reveal-up">
                    <?php if($pkg['popular']): ?><div class="popular-badge">Paling Sering Diminta</div><?php endif; ?>
                    <h3 class="price-name"><?= htmlspecialchars($pkg['name']) ?></h3>
                    <div class="price-value"><?= htmlspecialchars($pkg['price']) ?></div>
                    <p class="price-desc"><?= htmlspecialchars($pkg['desc']) ?></p>
                    <ul class="price-features">
                        <?php foreach($pkg['features'] as $feat): ?>
                        <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg> <?= htmlspecialchars($feat) ?></li>
                        <?php endforeach; ?>
                    </ul>
                    <a href="#contact" class="btn <?= $pkg['popular'] ? 'btn-primary' : 'btn-outline' ?> btn-full">Pilih Paket Ini</a>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <section class="section bg-light" id="testimonials">
        <div class="container">
            <div class="section-header reveal-up">
                <h2 class="section-title">Apa Kata Mereka</h2>
            </div>
            <div class="grid test-grid">
                <?php foreach($testimonials as $test): ?>
                <div class="test-card reveal-up">
                    <div class="test-quote">"<?= htmlspecialchars($test['text']) ?>"</div>
                    <div class="test-author">
                        <strong><?= htmlspecialchars($test['name']) ?></strong>
                        <span><?= htmlspecialchars($test['device']) ?></span>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <section class="section" id="faq">
        <div class="container">
            <div class="section-header reveal-up">
                <h2 class="section-title">Pertanyaan Sering Diajukan</h2>
            </div>
            <div class="faq-wrapper reveal-up">
                <?php foreach($faqs as $faq): ?>
                <div class="faq-item">
                    <button class="faq-question">
                        <?= htmlspecialchars($faq['q']) ?>
                        <svg class="faq-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"></polyline></svg>
                    </button>
                    <div class="faq-answer">
                        <p><?= htmlspecialchars($faq['a']) ?></p>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <section class="section bg-light" id="contact">
        <div class="container">
            <div class="contact-box reveal-up">
                <div class="contact-info">
                    <h2>Mulai Konsultasi</h2>
                    <p>Isi form dengan detail, dan kita bahas solusinya santai via WhatsApp.</p>
                    
                    <div class="info-list">
                        <div class="info-item">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                            <span>+<?= htmlspecialchars($config['whatsapp']) ?></span>
                        </div>
                        <div class="info-item">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                            <span><?= htmlspecialchars($config['location']) ?></span>
                        </div>
                        <div class="info-item">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
                            <span><?= htmlspecialchars($config['business_hours']) ?></span>
                        </div>
                    </div>
                </div>
                <div class="contact-form-container">
                    <form id="consultForm" action="submit.php" method="POST">
                        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                        <div class="form-group">
                            <label for="name">Nama Lengkap</label>
                            <input type="text" id="name" name="name" required placeholder="Cth: Budi" maxlength="50">
                        </div>
                        <div class="form-group">
                            <label for="phone">Nomor WhatsApp</label>
                            <input type="tel" id="phone" name="phone" required placeholder="Cth: 08123456789" maxlength="20">
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="device">Jenis Perangkat</label>
                                <select id="device" name="device" required>
                                    <option value="" disabled selected>Pilih Perangkat</option>
                                    <option value="Laptop">Laptop</option>
                                    <option value="PC Desktop">PC Desktop</option>
                                    <option value="Smartphone/Android">Smartphone / Android</option>
                                    <option value="Lainnya">Lainnya</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="service">Jenis Layanan</label>
                                <select id="service" name="service" required>
                                    <option value="" disabled selected>Pilih Layanan</option>
                                    <option value="Service Hardware">Service Hardware (Mati Total/Part)</option>
                                    <option value="Service Software">Service Software (Install OS/Flash)</option>
                                    <option value="Upgrade Part">Upgrade SSD / RAM</option>
                                    <option value="Cleaning Thermal">Cleaning & Repaste Thermal</option>
                                    <option value="Belum Tahu">Belum Tahu (Konsultasi Awal)</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="issue">Detail Keluhan</label>
                            <textarea id="issue" name="issue" required placeholder="Ceritakan detail keluhannya. Cth: Laptop mati total setelah kena air..." rows="4" maxlength="500"></textarea>
                        </div>
                        <div id="form-alert" class="alert d-none"></div>
                        <button type="submit" class="btn btn-primary btn-full btn-submit" id="btnSubmit">Kirim & Chat WhatsApp</button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <section class="section final-cta bg-navy">
        <div class="container text-center reveal-up">
            <h2 class="text-white">Perangkat Bermasalah? Jangan Ditebak-Tebak.</h2>
            <p class="text-white">Kirim keluhannya dulu. Nanti dibantu cek kemungkinan masalah, estimasi, dan langkah terbaik secara rapi dan profesional.</p>
            <a href="#contact" class="btn btn-primary btn-lg mt-4">Chat WhatsApp Sekarang</a>
        </div>
    </section>

    <footer class="footer">
        <div class="container footer-grid">
            <div class="footer-brand">
                <h3><?= htmlspecialchars($config['brand_name']) ?></h3>
                <p><?= htmlspecialchars($config['tagline']) ?></p>
            </div>
            <div class="footer-links">
                <h4>Navigasi</h4>
                <a href="#services">Layanan</a>
                <a href="#pricing">Paket & Harga</a>
                <a href="#workflow">Alur Kerja</a>
                <a href="#faq">FAQ</a>
            </div>
            <div class="footer-contact">
                <h4>Hubungi Kami</h4>
                <p>WhatsApp: +<?= htmlspecialchars($config['whatsapp']) ?></p>
                <p>Email: <?= htmlspecialchars($config['email']) ?></p>
                <p><?= htmlspecialchars($config['location']) ?></p>
            </div>
        </div>
        <div class="footer-bottom">
            <div class="container">
                <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($config['brand_name']) ?>. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <a href="https://wa.me/<?= htmlspecialchars($config['whatsapp']) ?>" class="floating-wa" target="_blank" aria-label="WhatsApp">
        <svg viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51a12.8 12.8 0 0 0-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.82 9.82 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413Z"/></svg>
    </a>

    <script>const WA_NUM = "<?= htmlspecialchars($config['whatsapp']) ?>";</script>
    <script src="assets/js/app.js"></script>
</body>
</html>